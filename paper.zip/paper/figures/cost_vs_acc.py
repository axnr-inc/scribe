#!/usr/bin/env python3
"""
Figure 2 for SCRIBE paper (ICDM 2026).

Cost-vs-accuracy Pareto frontier on:
  (left)  5-task DABStep "falsifier" subset
  (right) Full DABStep dev set (easy+hard combined, weighted by 72+378=450)

Run:
    cd paper/figures && python3 cost_vs_acc.py
Produces: cost_vs_acc.pdf
"""

import matplotlib
import matplotlib.pyplot as plt
import numpy as np

# ---- Style ---------------------------------------------------------------
matplotlib.rcParams["font.family"] = "serif"
matplotlib.rcParams["font.serif"] = ["Times New Roman", "Times", "DejaVu Serif"]
matplotlib.rcParams["mathtext.fontset"] = "stix"
matplotlib.rcParams["axes.labelsize"] = 8
matplotlib.rcParams["axes.titlesize"] = 8
matplotlib.rcParams["xtick.labelsize"] = 7
matplotlib.rcParams["ytick.labelsize"] = 7
matplotlib.rcParams["legend.fontsize"] = 6.5
matplotlib.rcParams["pdf.fonttype"] = 42  # embed TrueType for portability

# IEEE double-column-ish wide figure: ~17.6cm x 6cm
FIG_W_IN = 17.6 / 2.54
FIG_H_IN = 6.5 / 2.54

SCRIBE_BLUE = "#1f4e9e"
BASELINE_GREY = "#666666"


def style_for(family):
    """Return (marker, color, size) for a system family."""
    return {
        "kimi":   ("o", BASELINE_GREY, 55),
        "gpt5":   ("D", BASELINE_GREY, 50),
        "dsstar": ("^", BASELINE_GREY, 70),
        "scribe": ("*", SCRIBE_BLUE,   140),
    }[family]


def pareto_front(points):
    """Given list of (cost, acc, ...), return points on the upper-left Pareto
    frontier sorted by cost ascending. A point dominates if it has lower cost
    AND higher-or-equal accuracy (or vice versa)."""
    pts = sorted(points, key=lambda p: (p[0], -p[1]))
    front = []
    best_acc = -1
    for p in pts:
        if p[1] > best_acc:
            front.append(p)
            best_acc = p[1]
    return front


def plot_panel(ax, data, title, show_callout=False, ymin=0, ymax=100):
    # Pareto frontier (use cost, acc only)
    front = pareto_front([(d["cost"], d["acc"]) for d in data])
    fx = [p[0] for p in front]
    fy = [p[1] for p in front]
    ax.plot(fx, fy, linestyle="--", color=SCRIBE_BLUE, linewidth=1.0,
            alpha=0.6, zorder=1, label="Pareto frontier")

    # Points
    for d in data:
        marker, color, size = style_for(d["family"])
        edge = "white" if d["family"] == "scribe" else color
        ax.scatter(d["cost"], d["acc"], marker=marker, s=size,
                   color=color, edgecolors=edge, linewidths=0.7,
                   zorder=3)
        # Label placement
        dx, dy, ha, va = d.get("offset", (1.12, 0, "left", "center"))
        ax.annotate(d["label"],
                    xy=(d["cost"], d["acc"]),
                    xytext=(d["cost"] * dx, d["acc"] + dy),
                    fontsize=6.5, ha=ha, va=va, color="black")

    # Axes formatting
    ax.set_xscale("log")
    ax.set_xlim(0.008, 1.2)
    ax.set_ylim(ymin, ymax)
    ax.set_xlabel(r"Cost per task (USD, log scale)")
    ax.set_ylabel(r"Accuracy / pass-rate (\%)" if matplotlib.rcParams.get("text.usetex") else "Accuracy / pass-rate (%)")
    ax.set_title(title)
    ax.grid(True, which="both", linestyle=":", linewidth=0.4, alpha=0.6)
    ax.set_axisbelow(True)
    for spine in ("top", "right"):
        ax.spines[spine].set_visible(False)


def main():
    fig, (ax_l, ax_r) = plt.subplots(
        1, 2, figsize=(FIG_W_IN, FIG_H_IN), sharey=False
    )

    # ---- Left panel: 5-task falsifier subset -----------------------------
    subset = [
        {"family": "kimi",   "cost": 0.02, "acc": 20.0,
         "label": "Kimi-K2.6 solo",      "offset": (1.18, 4, "left", "bottom")},
        {"family": "gpt5",   "cost": 0.37, "acc": 20.0,
         "label": "GPT-5 solo",          "offset": (0.85, -7, "right", "top")},
        {"family": "scribe", "cost": 0.10, "acc": 80.0,
         "label": "SCRIBE (GPT-5 spec\n + Kimi exec)",
         "offset": (1.18, -4, "left", "top")},
    ]
    plot_panel(ax_l, subset, "(a) 5-task DABStep falsifier subset", ymin=0, ymax=100)

    # Callout: "3.7x cheaper at higher accuracy" between GPT-5 solo and SCRIBE
    ax_l.annotate(
        "3.7$\\times$ cheaper\n+60 pp accuracy",
        xy=(0.10, 80.0),                 # SCRIBE point
        xytext=(0.014, 55),              # text location
        fontsize=6.5, color=SCRIBE_BLUE,
        ha="left", va="center",
        arrowprops=dict(arrowstyle="->", color=SCRIBE_BLUE,
                        lw=0.7, connectionstyle="arc3,rad=0.15"),
    )
    # Also point to GPT-5 baseline
    ax_l.annotate(
        "",
        xy=(0.37, 20.0),
        xytext=(0.05, 50),
        arrowprops=dict(arrowstyle="->", color=SCRIBE_BLUE,
                        lw=0.5, alpha=0.5,
                        connectionstyle="arc3,rad=-0.25"),
    )

    # ---- Right panel: full DABStep dev set -------------------------------
    # One canonical SCRIBE point — no single-run/best-of-N/+recovery split.
    full = [
        {"family": "kimi",   "cost": 0.02, "acc": 46.0,
         "label": "Kimi-K2.6 solo",
         "offset": (1.25, 0, "left", "center")},
        {"family": "dsstar", "cost": 0.28, "acc": 50.4,
         "label": "DS-STAR (GPT-5)$^\\dagger$",
         "offset": (1.0, -7.5, "center", "top")},
        {"family": "dsstar", "cost": 0.32, "acc": 52.0,
         "label": "DS-STAR (Gemini-2.5-Pro)$^\\dagger$",
         "offset": (1.18, -3, "left", "top")},
        {"family": "scribe", "cost": 0.33, "acc": 59.8,
         "label": "SCRIBE",
         "offset": (1.10, 3.5, "left", "bottom")},
    ]
    plot_panel(ax_r, full, "(b) Full DABStep dev (450 tasks)", ymin=30, ymax=75)

    # Footnote for hidden-test estimates
    ax_r.text(
        0.01, -0.28,
        r"$^\dagger$DS-STAR cost estimated (paper does not report cost/task)",
        transform=ax_r.transAxes, fontsize=5.5, color="black",
        ha="left", va="top", style="italic",
    )

    # ---- Shared legend (system families) ---------------------------------
    legend_handles = [
        plt.Line2D([0], [0], marker="o", color="w",
                   markerfacecolor=BASELINE_GREY, markersize=6,
                   label="Kimi-K2.6 solo"),
        plt.Line2D([0], [0], marker="D", color="w",
                   markerfacecolor=BASELINE_GREY, markersize=5.5,
                   label="GPT-5 solo"),
        plt.Line2D([0], [0], marker="^", color="w",
                   markerfacecolor=BASELINE_GREY, markersize=7,
                   label="DS-STAR"),
        plt.Line2D([0], [0], marker="*", color="w",
                   markerfacecolor=SCRIBE_BLUE, markersize=10,
                   label="SCRIBE (ours)"),
        plt.Line2D([0], [0], linestyle="--", color=SCRIBE_BLUE,
                   alpha=0.6, label="Pareto frontier"),
    ]
    fig.legend(
        handles=legend_handles,
        loc="upper center", bbox_to_anchor=(0.5, 1.04),
        ncol=5, frameon=False, fontsize=6.5,
        handletextpad=0.4, columnspacing=1.2,
    )

    fig.tight_layout(rect=(0, 0.02, 1, 0.96))
    out = "cost_vs_acc.pdf"
    plt.savefig(out, bbox_inches="tight", format="pdf")
    print(f"wrote {out}")


if __name__ == "__main__":
    main()
