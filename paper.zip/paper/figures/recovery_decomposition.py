"""Recovery vs regression decomposition by split.

Back-to-back horizontal bars per split (Easy-72, Hard-378, Combined): the
positive side shows recoveries (+), the negative side shows regressions (-).
Net swing is annotated to the right of each row.
"""

import matplotlib
import matplotlib.pyplot as plt
import numpy as np

matplotlib.rcParams["font.family"] = "serif"

splits = ["Easy-72", "Hard-378", "Combined"]
recoveries = [15, 60, 75]
regressions = [4, 44, 48]   # plotted on negative x-axis
nets = [r - g for r, g in zip(recoveries, regressions)]

fig, ax = plt.subplots(figsize=(12 / 2.54, 7 / 2.54))
y = np.arange(len(splits))
bar_h = 0.55

bars_pos = ax.barh(y, recoveries, height=bar_h, color="#2ca02c",
                   edgecolor="black", linewidth=0.5, label="Recoveries (+)")
bars_neg = ax.barh(y, [-g for g in regressions], height=bar_h, color="#d62728",
                   edgecolor="black", linewidth=0.5, label="Regressions (-)")

# Numeric labels inside bars.
for rect, val in zip(bars_pos, recoveries):
    ax.text(rect.get_width() + 1.2, rect.get_y() + rect.get_height() / 2,
            f"+{val}", va="center", ha="left", fontsize=8, color="#2ca02c")
for rect, val in zip(bars_neg, regressions):
    ax.text(rect.get_width() - 1.2, rect.get_y() + rect.get_height() / 2,
            f"-{val}", va="center", ha="right", fontsize=8, color="#d62728")

# Net annotation on the far right.
xmax = max(recoveries) + 20
xmin = -(max(regressions) + 15)
for yi, net in zip(y, nets):
    sign = "+" if net >= 0 else ""
    ax.text(xmax - 1, yi, f"net {sign}{net}",
            va="center", ha="right", fontsize=8.5,
            fontweight="bold", color="black",
            bbox=dict(boxstyle="round,pad=0.2",
                      facecolor="#f0f0f0", edgecolor="gray", linewidth=0.4))

ax.axvline(0, color="black", lw=0.8)
ax.set_yticks(y)
ax.set_yticklabels(splits, fontsize=9)
ax.set_xlabel("Number of tasks (regressions $\\leftarrow$ | $\\rightarrow$ recoveries)",
              fontsize=9)
ax.set_xlim(xmin, xmax)
ax.set_title("Recovery vs regression decomposition by split", fontsize=10)
ax.tick_params(axis="x", labelsize=8)
ax.grid(axis="x", linestyle=":", linewidth=0.5, alpha=0.6)
ax.set_axisbelow(True)

# Symmetric x-axis tick labels (show absolute counts).
ticks = np.array([-60, -40, -20, 0, 20, 40, 60, 80])
ax.set_xticks(ticks)
ax.set_xticklabels([str(abs(int(t))) for t in ticks])

ax.legend(fontsize=8, loc="lower right", frameon=False)

plt.tight_layout()
plt.savefig("paper/figures/recovery_decomposition.pdf",
            bbox_inches="tight", format="pdf")
plt.close(fig)
