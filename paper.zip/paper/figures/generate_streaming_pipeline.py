"""Generate streaming_pipeline.pdf using matplotlib.
Shows spec extraction (sequential) overlapping with executor runs (2 parallel workers).
"""
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, FancyArrowPatch

fig, ax = plt.subplots(figsize=(7.5, 3.0))

# Colors
SPEC_FACE = '#DCE6F4'; SPEC_EDGE = '#2B5BA0'
EXEC_FACE = '#DCEEDC'; EXEC_EDGE = '#2E7D32'

# Spec worker row (y=2)
spec_starts = [0.0, 1.3, 2.6, 3.9, 5.2, 6.5, 7.8]
spec_dur = 1.2
for i, x in enumerate(spec_starts):
    ax.add_patch(Rectangle((x, 1.85), spec_dur, 0.3,
                           facecolor=SPEC_FACE, edgecolor=SPEC_EDGE, linewidth=0.7))
    ax.text(x + spec_dur/2, 2.0, f"T$_{i+1}$", ha='center', va='center', fontsize=8)

# Executor worker 0 row (y=3)
exec0_starts = [1.3, 3.6, 5.9, 8.2]
exec0_tasks = [1, 3, 5, 7]
exec_dur = 1.9
for x, t in zip(exec0_starts, exec0_tasks):
    ax.add_patch(Rectangle((x, 2.85), exec_dur, 0.3,
                           facecolor=EXEC_FACE, edgecolor=EXEC_EDGE, linewidth=0.7))
    ax.text(x + exec_dur/2, 3.0, f"T$_{t}$", ha='center', va='center', fontsize=8)

# Executor worker 1 row (y=4)
exec1_starts = [2.6, 4.9, 7.2]
exec1_tasks = [2, 4, 6]
for x, t in zip(exec1_starts, exec1_tasks):
    ax.add_patch(Rectangle((x, 3.85), exec_dur, 0.3,
                           facecolor=EXEC_FACE, edgecolor=EXEC_EDGE, linewidth=0.7))
    ax.text(x + exec_dur/2, 4.0, f"T$_{t}$", ha='center', va='center', fontsize=8)

# Hand-off arrows (dashed)
arrows = [(1.2, 2.15, 1.3, 2.85), (2.5, 2.15, 2.6, 3.85),
          (3.8, 2.15, 3.6, 2.85), (5.1, 2.15, 4.9, 3.85)]
for x1, y1, x2, y2 in arrows:
    ax.annotate('', xy=(x2, y2), xytext=(x1, y1),
                arrowprops=dict(arrowstyle='->', linestyle='--', color='gray', lw=0.6))

# Row labels
ax.text(-0.3, 2.0, 'spec worker', ha='right', va='center', fontsize=9, weight='bold')
ax.text(-0.3, 3.0, 'executor 0', ha='right', va='center', fontsize=9, weight='bold')
ax.text(-0.3, 4.0, 'executor 1', ha='right', va='center', fontsize=9, weight='bold')

# Time axis
ax.annotate('', xy=(10.5, 1.3), xytext=(-0.3, 1.3),
            arrowprops=dict(arrowstyle='->', color='black', lw=0.7))
ax.text(10.7, 1.3, 'wall time', ha='left', va='center', fontsize=8)

# Legend
ax.add_patch(Rectangle((0.0, 0.4), 0.4, 0.2, facecolor=SPEC_FACE, edgecolor=SPEC_EDGE))
ax.text(0.5, 0.5, 'spec extraction (sequential)', va='center', fontsize=8)
ax.add_patch(Rectangle((4.0, 0.4), 0.4, 0.2, facecolor=EXEC_FACE, edgecolor=EXEC_EDGE))
ax.text(4.5, 0.5, 'executor (2 workers, sharded API keys)', va='center', fontsize=8)
ax.annotate('', xy=(8.4, 0.5), xytext=(8.0, 0.5),
            arrowprops=dict(arrowstyle='->', linestyle='--', color='gray', lw=0.6))
ax.text(8.5, 0.5, 'hand-off', va='center', fontsize=8)

ax.set_xlim(-1.8, 11.0)
ax.set_ylim(0.0, 4.6)
ax.set_aspect('auto')
ax.axis('off')

plt.tight_layout()
plt.savefig('streaming_pipeline.pdf', bbox_inches='tight', pad_inches=0.05)
plt.savefig('streaming_pipeline.png', bbox_inches='tight', pad_inches=0.05, dpi=200)
print("wrote streaming_pipeline.pdf + .png")
