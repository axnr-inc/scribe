"""Figure 3 for SCRIBE (ICDM 2026): residual hard-378 failure families.

Generates a horizontal bar chart of the 13 failure families identified in the
manual analysis of residual errors on the hard-378 subset, color-coded by
attribution class (model / harness / benchmark / hybrids).

Run:
    python3 failure_families.py
Produces:
    failure_families.pdf  (vector, IEEE single-column)
"""

from __future__ import annotations

import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import Patch

# --- Style --------------------------------------------------------------------
plt.rcParams["font.family"] = "serif"
plt.rcParams["font.size"] = 8
plt.rcParams["axes.linewidth"] = 0.6
plt.rcParams["xtick.major.width"] = 0.6
plt.rcParams["ytick.major.width"] = 0.6
plt.rcParams["pdf.fonttype"] = 42  # TrueType for embedded fonts

# --- Data ---------------------------------------------------------------------
# (id, label, count, class)
# class in: model, harness, benchmark, benchmark+model, harness+model
families = [
    ("F1",  "Fraud-move ACI selection",                   25, "benchmark+model"),
    ("F2",  "Over-strict matching $\\rightarrow$ NA",     38, "model"),
    ("F3",  "Most-expensive MCC: wrong universe",         10, "model"),
    ("F4",  "Most-exp./cheapest ACI letter pick",         18, "model"),
    ("F5",  "Avg-fee per (scheme/acct) def-shift",        15, "model"),
    ("F6",  "Counterfactual-MCC scenario",                18, "model"),
    ("F7",  "Cheapest/most-exp. scheme pick",              6, "model"),
    ("F8",  "Relative-fee delta sign/rounding",           14, "harness+model"),
    ("F9",  "Hit-cap, empty prediction",                   8, "harness+model"),
    ("F10", "Infrastructure / premature exit",             4, "harness"),
    ("F11", "Fee-IDs list (over-strict)",                  4, "model"),
    ("F12", "Token / generation glitch",                   3, "model"),
    ("F13", "Benchmark gold-format ambiguity",            25, "benchmark"),
]

# Sort by count descending (largest at top of horizontal chart)
families_sorted = sorted(families, key=lambda r: r[2], reverse=True)

# --- Colors -------------------------------------------------------------------
COLOR_MODEL     = "#3b6fb6"   # blue
COLOR_HARNESS   = "#e08214"   # orange
COLOR_BENCHMARK = "#9a9a9a"   # grey

def primary_color(cls: str) -> str:
    if cls == "model":            return COLOR_MODEL
    if cls == "harness":          return COLOR_HARNESS
    if cls == "benchmark":        return COLOR_BENCHMARK
    if cls == "benchmark+model":  return COLOR_BENCHMARK  # base, overlay below
    if cls == "harness+model":    return COLOR_HARNESS    # base, overlay below
    return "#444444"

def secondary_color(cls: str):
    if cls == "benchmark+model":  return COLOR_MODEL
    if cls == "harness+model":    return COLOR_MODEL
    return None

# --- Figure -------------------------------------------------------------------
# IEEE single-column: 8.5 cm x 7 cm  ->  3.35" x 2.76"
fig_w_in = 8.5 / 2.54
fig_h_in = 7.0 / 2.54
fig, ax = plt.subplots(figsize=(fig_w_in, fig_h_in))

y_positions = list(range(len(families_sorted)))
y_positions.reverse()  # so the largest count is at the top

ytick_labels = []
for ypos, (fid, label, count, cls) in zip(y_positions, families_sorted):
    base = primary_color(cls)
    sec = secondary_color(cls)
    hatch = "////" if fid == "F13" else None

    if sec is None:
        ax.barh(
            ypos, count, height=0.72,
            color=base, edgecolor="black", linewidth=0.4,
            hatch=hatch,
        )
    else:
        # two-tone split: first half base, second half secondary
        half = count / 2.0
        ax.barh(
            ypos, half, height=0.72,
            color=base, edgecolor="black", linewidth=0.4,
        )
        ax.barh(
            ypos, half, left=half, height=0.72,
            color=sec, edgecolor="black", linewidth=0.4,
        )

    # count label at end of bar
    label_txt = f"{count}"
    if fid == "F13":
        label_txt = f"{count} (overlaps F1)"
    ax.text(
        count + 0.6, ypos, label_txt,
        va="center", ha="left", fontsize=7,
    )

    ytick_labels.append(f"{fid}: {label}")

ax.set_yticks(y_positions)
ax.set_yticklabels(ytick_labels, fontsize=7)
# y_positions was already reversed so largest count sits at the top.

ax.set_xlabel("Tasks (out of residual hard-378)", fontsize=8)
ax.set_xlim(0, 56)
ax.tick_params(axis="x", labelsize=7)
ax.spines["top"].set_visible(False)
ax.spines["right"].set_visible(False)
ax.xaxis.set_ticks_position("bottom")
ax.yaxis.set_ticks_position("left")
ax.grid(axis="x", linestyle=":", linewidth=0.4, color="#bbbbbb", zorder=0)
ax.set_axisbelow(True)

# --- Legend -------------------------------------------------------------------
legend_handles = [
    Patch(facecolor=COLOR_MODEL,     edgecolor="black", linewidth=0.4, label="model"),
    Patch(facecolor=COLOR_HARNESS,   edgecolor="black", linewidth=0.4, label="harness"),
    Patch(facecolor=COLOR_BENCHMARK, edgecolor="black", linewidth=0.4, label="benchmark"),
    Patch(facecolor="white", edgecolor="black", linewidth=0.4,
          hatch="////", label="overlap w/ F1"),
]
ax.legend(
    handles=legend_handles,
    loc="lower right",
    bbox_to_anchor=(1.0, 0.02),
    frameon=True,
    fontsize=6.5,
    handlelength=1.4,
    handleheight=1.0,
    borderpad=0.4,
    labelspacing=0.3,
)

# --- Annotation: total residual ----------------------------------------------
ax.text(
    1.0, 1.015,
    r"Total residual $\approx$ 184 tasks (F13 overlaps F1)",
    transform=ax.transAxes,
    ha="right", va="bottom",
    fontsize=6.5, style="italic", color="#333333",
)

plt.tight_layout(pad=0.3)
plt.savefig("failure_families.pdf", bbox_inches="tight", format="pdf")
print("Wrote failure_families.pdf")
