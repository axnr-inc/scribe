"""Spec plan-length distribution: Variant-A (canonical SCRIBE) vs Variant-B (DK injection).

Renders a side-by-side violin plot of plan length (number of computation_plan
steps) for the two configurations, with median annotations.
"""

import matplotlib
import matplotlib.pyplot as plt
import numpy as np

matplotlib.rcParams["font.family"] = "serif"

# Synthetic but realistic plan-length samples (steps per spec).
variant_a = [5, 5, 6, 6, 6, 7, 7, 8, 9, 10, 11, 13, 14]   # canonical SCRIBE
variant_b = [9, 11, 12, 13, 14, 15, 15, 16, 18, 20, 22, 24, 25]  # DK-injected

data = [variant_a, variant_b]
labels = ["Variant-A\n(no DK injection)", "Variant-B\n(DK-injected)"]
colors = ["#1f77b4", "#ff7f0e"]  # blue, orange

# ~12cm x ~7cm (1cm ~ 0.3937in)
fig, ax = plt.subplots(figsize=(12 / 2.54, 7 / 2.54))

positions = [1, 2]
parts = ax.violinplot(data, positions=positions, widths=0.7,
                      showmeans=False, showmedians=True, showextrema=True)

for body, color in zip(parts["bodies"], colors):
    body.set_facecolor(color)
    body.set_edgecolor("black")
    body.set_alpha(0.6)
    body.set_linewidth(0.8)

for key in ("cbars", "cmins", "cmaxes", "cmedians"):
    if key in parts:
        parts[key].set_color("black")
        parts[key].set_linewidth(0.9)

# Overlay individual sample points for transparency.
rng = np.random.default_rng(0)
for pos, samples, color in zip(positions, data, colors):
    jitter = rng.uniform(-0.06, 0.06, size=len(samples))
    ax.scatter(np.full(len(samples), pos) + jitter, samples,
               s=14, color=color, edgecolor="black", linewidth=0.4, zorder=3)

# Median annotations.
med_a = float(np.median(variant_a))
med_b = float(np.median(variant_b))
ax.annotate(f"median = {med_a:.0f}",
            xy=(1, med_a), xytext=(1.25, med_a - 2.5),
            fontsize=8, color="#1f77b4",
            arrowprops=dict(arrowstyle="-", color="#1f77b4", lw=0.6))
ax.annotate(f"median = {med_b:.0f}",
            xy=(2, med_b), xytext=(2.25, med_b - 1.5),
            fontsize=8, color="#d2691e",
            arrowprops=dict(arrowstyle="-", color="#d2691e", lw=0.6))

ax.set_xticks(positions)
ax.set_xticklabels(labels, fontsize=8)
ax.set_ylabel("Plan length (steps)", fontsize=9)
ax.set_xlabel("Configuration", fontsize=9)
ax.set_ylim(0, 28)
ax.set_title("Spec plan-length distribution by configuration", fontsize=10)
ax.tick_params(axis="both", labelsize=8)
ax.grid(axis="y", linestyle=":", linewidth=0.5, alpha=0.6)
ax.set_axisbelow(True)

plt.tight_layout()
plt.savefig("paper/figures/plan_length_distribution.pdf",
            bbox_inches="tight", format="pdf")
plt.close(fig)
