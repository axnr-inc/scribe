"""Generate arch.pdf using matplotlib.
Shows the FULL SCRIBE architecture including:
  - Spec Agent (with I-1 interpretations field in frozen spec)
  - Review Agent (six-verdict cascade)
  - ReAct Executor (with HELPER_MANIFEST preamble from semantic-layer insight)
  - No provider names (anonymous-friendly + venue-agnostic).
"""
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from matplotlib.patches import Rectangle

fig, ax = plt.subplots(figsize=(7.0, 7.6))

# Colors
DOC_FACE = '#F4ECD8'; DOC_EDGE = '#7A6A3A'
SPEC_FACE = '#FFF6D6'; SPEC_EDGE = '#8A6E1F'
FRONTIER_FACE = '#DCE6F4'; FRONTIER_EDGE = '#2B5BA0'
EXEC_FACE = '#DCEEDC'; EXEC_EDGE = '#2E7D32'
HELPER_FACE = '#F0E6F4'; HELPER_EDGE = '#6A4A8A'

# Coordinates (x, y, w, h)
def box(ax, x, y, w, h, face, edge, lw=0.8):
    p = FancyBboxPatch((x, y), w, h,
                       boxstyle="round,pad=0.02,rounding_size=0.05",
                       facecolor=face, edgecolor=edge, linewidth=lw)
    ax.add_patch(p)

# --- Source documents (top) ---
box(ax, 1.4, 9.4, 3.2, 0.7, DOC_FACE, DOC_EDGE)
ax.text(3.0, 9.85, 'Source documents', ha='center', va='center',
        fontsize=10, weight='bold')
ax.text(3.0, 9.55, 'manual.md, fees.json, schemas, data lake',
        ha='center', va='center', fontsize=8, style='italic')

# --- Spec Agent ---
box(ax, 1.4, 7.9, 3.2, 0.9, FRONTIER_FACE, FRONTIER_EDGE)
ax.text(3.0, 8.50, 'Spec Agent', ha='center', va='center',
        fontsize=10.5, weight='bold')
ax.text(3.0, 8.15, 'strong model, clean session',
        ha='center', va='center', fontsize=8, style='italic')

# --- Frozen spec (with I-1 interpretations highlighted) ---
box(ax, 1.0, 5.95, 4.0, 1.3, SPEC_FACE, SPEC_EDGE)
ax.text(3.0, 7.0, 'Frozen spec', ha='center', va='center',
        fontsize=10, weight='bold')
ax.text(3.0, 6.65, 'interpretations[] (I-1 gate)',
        ha='center', va='center', fontsize=8.5, style='italic', color='#603000')
ax.text(3.0, 6.40, 'chosen_interpretation + computation_plan',
        ha='center', va='center', fontsize=8, style='italic')
ax.text(3.0, 6.15, 'expected_output_format',
        ha='center', va='center', fontsize=8, style='italic')

# --- HELPER_MANIFEST (new node from semantic-layer insight) ---
box(ax, 5.4, 5.95, 2.4, 1.3, HELPER_FACE, HELPER_EDGE)
ax.text(6.6, 7.0, 'HELPER_MANIFEST', ha='center', va='center',
        fontsize=9.5, weight='bold')
ax.text(6.6, 6.65, 'paradigm-level helpers',
        ha='center', va='center', fontsize=8, style='italic')
ax.text(6.6, 6.40, 'read_multi_header_excel,',
        ha='center', va='center', fontsize=7.3, family='monospace')
ax.text(6.6, 6.20, 'parse_missing_marker, ...',
        ha='center', va='center', fontsize=7.3, family='monospace')

# --- ReAct Executor ---
box(ax, 1.4, 4.0, 3.2, 1.0, EXEC_FACE, EXEC_EDGE)
ax.text(3.0, 4.65, 'ReAct Executor', ha='center', va='center',
        fontsize=10.5, weight='bold')
ax.text(3.0, 4.30, 'smaller open-weights model',
        ha='center', va='center', fontsize=8, style='italic')
ax.text(3.0, 4.10, 'Python REPL + tool surface',
        ha='center', va='center', fontsize=7.5, family='monospace')

# --- Review Agent (right side, with 6-verdict cascade) ---
box(ax, 5.4, 4.0, 2.4, 1.5, FRONTIER_FACE, FRONTIER_EDGE)
ax.text(6.6, 5.15, 'Review Agent', ha='center', va='center',
        fontsize=10.5, weight='bold')
ax.text(6.6, 4.85, 'same session as Spec',
        ha='center', va='center', fontsize=8, style='italic')
ax.text(6.6, 4.60, '6-verdict cascade:',
        ha='center', va='center', fontsize=8, weight='bold', color='#B22222')
ax.text(6.6, 4.38, 'SPEC_WRONG | SPEC_DOUBT',
        ha='center', va='center', fontsize=6.8, family='monospace', color='#B22222')
ax.text(6.6, 4.22, 'BLIND_SPOT | EXEC_WRONG',
        ha='center', va='center', fontsize=6.8, family='monospace', color='#B22222')
ax.text(6.6, 4.06, 'NA_CONFIRMED | ANSWER',
        ha='center', va='center', fontsize=6.8, family='monospace', color='#B22222')

# --- Final answer ---
box(ax, 1.4, 2.2, 3.2, 0.7, 'white', 'black')
ax.text(3.0, 2.55, 'Final answer', ha='center', va='center',
        fontsize=10, weight='bold')

# --- Arrows (main flow, blue) ---
def arrow(ax, x1, y1, x2, y2, color='#1F4E9E', style='-', lw=0.9, dashed=False):
    ls = '--' if dashed else '-'
    a = FancyArrowPatch((x1, y1), (x2, y2),
                        arrowstyle='->', mutation_scale=14,
                        color=color, linewidth=lw, linestyle=ls)
    ax.add_patch(a)

# Main flow (solid blue)
arrow(ax, 3.0, 9.4, 3.0, 8.8, '#1F4E9E')
ax.text(3.0, 9.13, 'read', ha='center', va='center',
        fontsize=7.5, style='italic',
        bbox=dict(facecolor='white', edgecolor='none', pad=0.5))

arrow(ax, 3.0, 7.9, 3.0, 7.25, '#1F4E9E')
ax.text(3.0, 7.63, 'save_spec', ha='center', va='center',
        fontsize=7.5, style='italic', family='monospace',
        bbox=dict(facecolor='white', edgecolor='none', pad=0.5))

arrow(ax, 3.0, 5.95, 3.0, 5.0, '#1F4E9E')
ax.text(3.0, 5.5, 'run_python', ha='center', va='center',
        fontsize=7.5, style='italic', family='monospace',
        bbox=dict(facecolor='white', edgecolor='none', pad=0.5))

arrow(ax, 3.0, 4.0, 3.0, 2.9, '#1F4E9E')
ax.text(3.0, 3.45, 'emit answer', ha='center', va='center',
        fontsize=7.5, style='italic',
        bbox=dict(facecolor='white', edgecolor='none', pad=0.5))

# Helper preamble loaded into executor (dotted)
arrow(ax, 5.4, 6.3, 4.6, 4.65, '#6A4A8A', dashed=False, lw=0.7)
ax.text(5.2, 5.5, 'preamble', ha='center', va='center',
        fontsize=7, style='italic', color='#6A4A8A',
        bbox=dict(facecolor='white', edgecolor='none', pad=0.5))

# Escalation: executor -> review (dashed red)
arrow(ax, 4.6, 4.5, 5.4, 4.5, '#B22222', dashed=True, lw=0.9)
ax.text(5.0, 4.65, 'ask_spec_agent', ha='center', va='center',
        fontsize=7.3, style='italic', family='monospace', color='#B22222',
        bbox=dict(facecolor='white', edgecolor='none', pad=0.5))

# Review -> revised spec back to frozen (dashed red, curved)
arrow(ax, 5.4, 5.3, 5.0, 6.4, '#B22222', dashed=True, lw=0.9)
ax.text(4.95, 5.9, 'revised spec', ha='center', va='center',
        fontsize=7.3, style='italic', color='#B22222',
        bbox=dict(facecolor='white', edgecolor='none', pad=0.5))

# Review -> docs (read_file, dotted)
arrow(ax, 6.6, 5.5, 4.6, 9.5, '#7A6A3A', dashed=True, lw=0.6)
ax.text(7.0, 7.5, 'read_file', ha='center', va='center',
        fontsize=7.3, style='italic', family='monospace', color='#7A6A3A',
        bbox=dict(facecolor='white', edgecolor='none', pad=0.5))

# --- Legend ---
legend_y = 0.7
ax.add_patch(Rectangle((0.6, legend_y+0.15), 0.3, 0.18, facecolor=FRONTIER_FACE, edgecolor=FRONTIER_EDGE))
ax.text(1.0, legend_y+0.24, 'strong model (Spec + Review)', va='center', fontsize=8)
ax.add_patch(Rectangle((3.8, legend_y+0.15), 0.3, 0.18, facecolor=EXEC_FACE, edgecolor=EXEC_EDGE))
ax.text(4.2, legend_y+0.24, 'open-weights executor', va='center', fontsize=8)
ax.add_patch(Rectangle((6.4, legend_y+0.15), 0.3, 0.18, facecolor=HELPER_FACE, edgecolor=HELPER_EDGE))
ax.text(6.8, legend_y+0.24, 'paradigm shim', va='center', fontsize=8)

# Line legend
ax.plot([0.6, 1.1], [legend_y-0.15, legend_y-0.15], color='#1F4E9E', linewidth=1.2)
ax.text(1.2, legend_y-0.15, 'main flow', va='center', fontsize=8)
ax.plot([3.0, 3.5], [legend_y-0.15, legend_y-0.15], color='#B22222', linewidth=1.2, linestyle='--')
ax.text(3.6, legend_y-0.15, 'escalation cascade', va='center', fontsize=8)
ax.plot([5.7, 6.2], [legend_y-0.15, legend_y-0.15], color='#7A6A3A', linewidth=0.8, linestyle='--')
ax.text(6.3, legend_y-0.15, 'read_file', va='center', fontsize=8)

ax.set_xlim(0.4, 8.2)
ax.set_ylim(0.2, 10.4)
ax.set_aspect('equal')
ax.axis('off')

plt.tight_layout()
plt.savefig('arch.pdf', bbox_inches='tight', pad_inches=0.1)
plt.savefig('arch.png', bbox_inches='tight', pad_inches=0.1, dpi=200)
print("wrote arch.pdf + arch.png")
