"""Cumulative iteration distribution by run outcome.

Two empirical CDFs (successful vs failed runs) of the iteration at which the
executor commits a final answer, with the iter=15 mandatory-escalation
threshold marked.
"""

import matplotlib
import matplotlib.pyplot as plt
import numpy as np

matplotlib.rcParams["font.family"] = "serif"

successful = [3, 4, 5, 5, 6, 6, 7, 7, 7, 8, 9, 10, 11, 12, 14]
failed = [11, 13, 15, 16, 16, 17, 18, 19, 21, 22, 24, 25, 28, 30, 32]


def ecdf(samples, x_grid):
    sorted_s = np.sort(np.asarray(samples, dtype=float))
    n = len(sorted_s)
    return np.searchsorted(sorted_s, x_grid, side="right") / n


x_grid = np.linspace(0, 35, 351)
cdf_s = ecdf(successful, x_grid)
cdf_f = ecdf(failed, x_grid)

fig, ax = plt.subplots(figsize=(12 / 2.54, 7 / 2.54))

ax.plot(x_grid, cdf_s, color="#2ca02c", lw=1.6,
        label=f"Successful (n={len(successful)})")
ax.plot(x_grid, cdf_f, color="#d62728", lw=1.6, linestyle="-",
        label=f"Failed (n={len(failed)})")

ax.axvline(15, color="black", linestyle="--", lw=0.9, alpha=0.7)
# Threshold label placed INSIDE the plot near the top of the vertical line,
# with a white background, so it never collides with the x-axis title.
ax.text(15.4, 0.55, "mandatory escalation\nthreshold (iter = 15)",
        fontsize=7.5, color="black", va="center", ha="left",
        bbox=dict(facecolor="white", edgecolor="none", pad=1.5))

frac_s_15 = float(np.mean(np.asarray(successful) <= 15))
frac_f_15 = float(np.mean(np.asarray(failed) <= 15))
ax.scatter([15, 15], [frac_s_15, frac_f_15],
           color=["#2ca02c", "#d62728"], s=22, zorder=4,
           edgecolor="black", linewidth=0.5)
# 100% label moved to the right of the marker (was directly above and
# clipped by the upper y-limit).
ax.annotate(f"{frac_s_15*100:.0f}%", xy=(15, frac_s_15),
            xytext=(16.0, frac_s_15 - 0.04),
            fontsize=8, color="#2ca02c", fontweight="bold")
ax.annotate(f"{frac_f_15*100:.0f}%", xy=(15, frac_f_15),
            xytext=(16.0, frac_f_15 + 0.02),
            fontsize=8, color="#d62728", fontweight="bold")

ax.set_xlim(0, 35)
ax.set_ylim(0, 1.08)  # extra headroom so the 100% marker isn't clipped
ax.set_xlabel("Executor iteration at final commit", fontsize=9)
ax.set_ylabel("Cumulative fraction of runs", fontsize=9)
ax.set_title("Cumulative iteration distribution by run outcome", fontsize=10)
ax.tick_params(axis="both", labelsize=8)
ax.grid(True, linestyle=":", linewidth=0.5, alpha=0.6)
ax.set_axisbelow(True)
ax.legend(fontsize=8, loc="lower right", frameon=False)

plt.tight_layout()
plt.savefig("escalation_iter_histogram.pdf",
            bbox_inches="tight", format="pdf")
plt.close(fig)
