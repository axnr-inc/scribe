"""
Figure: SCRIBE vs DS-STAR vs baselines bar chart.
Grouped bars by split (Easy, Hard, Combined). Annotates the dev-set vs
hidden-test caveat in the figure.
"""
import matplotlib.pyplot as plt
import matplotlib
import numpy as np

matplotlib.rcParams['font.family'] = 'serif'
matplotlib.rcParams['pdf.fonttype'] = 42

# Data (SCRIBE on dev set; DS-STAR rows from leaderboard / Nam et al. 2026)
splits = ['Easy (72)', 'Hard (378)', 'Combined (450)']
systems = {
    'Kimi-K2.6 solo':       [75.0, 40.5, 46.0],
    'DS-STAR (Gemini-2.5)': [87.5, 45.2, 52.0],
    'DS-STAR (GPT-5)':      [88.9, 43.1, 50.4],
    'SCRIBE (ours)':        [95.8, 52.9, 59.8],
}

colors = {
    'Kimi-K2.6 solo':       '#9aa0a6',
    'DS-STAR (Gemini-2.5)': '#bfa14a',
    'DS-STAR (GPT-5)':      '#7f6228',
    'SCRIBE (ours)':        '#1f4e9f',
}

fig, ax = plt.subplots(figsize=(8.0, 3.6))
x = np.arange(len(splits))
n = len(systems)
width = 0.78 / n

for i, (name, vals) in enumerate(systems.items()):
    pos = x - 0.39 + (i + 0.5) * width
    bars = ax.bar(pos, vals, width, label=name, color=colors[name],
                  edgecolor='black', linewidth=0.4)
    for b, v in zip(bars, vals):
        ax.annotate(f'{v:.1f}', xy=(b.get_x() + b.get_width()/2, v),
                    xytext=(0, 2), textcoords='offset points',
                    ha='center', va='bottom', fontsize=7)

ax.set_xticks(x)
ax.set_xticklabels(splits, fontsize=9)
ax.set_ylabel('Accuracy (\\%)', fontsize=10)
ax.set_ylim(0, 105)
ax.set_axisbelow(True)
ax.grid(True, axis='y', linestyle=':', alpha=0.4)
ax.legend(loc='upper right', fontsize=8, framealpha=0.95)

# Caveat note
fig.text(0.5, -0.03,
         'SCRIBE: public dev set with consensus gold. '
         'DS-STAR: DABStep leaderboard (hidden test set).',
         ha='center', fontsize=7, style='italic')

plt.tight_layout()
plt.savefig('/Users/suraj/Downloads/scribe/paper/figures/scribe_vs_dsstar.pdf',
            bbox_inches='tight', format='pdf')
print('wrote scribe_vs_dsstar.pdf')
