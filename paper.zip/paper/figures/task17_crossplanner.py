"""
Figure: Task-17 cross-planner study. Five different spec-author models on the
same task, same docs, same Kimi-K2.6 executor. Six runs (Planner-B sampled
twice) produce three distinct interpretations; only the pooled-volume reading
matches gold.
"""
import matplotlib.pyplot as plt
import matplotlib
import numpy as np

matplotlib.rcParams['font.family'] = 'serif'
matplotlib.rcParams['pdf.fonttype'] = 42

# Data from cross-planner study on task 17 ("lowest avg fraud rate per merchant")
runs = [
    ('Mid-tier Spec',           8.894813, 'H3 monthly-mean vol-wtd', False),
    ('Frontier Spec\n(sample 1)', 7.683437, 'H2 count-wtd',            False),
    ('Frontier Spec\n(sample 2)', 8.907926, 'H1 pooled vol-wtd',       True),
    ('Defensive Spec C',        8.907926, 'H1 pooled vol-wtd',       True),
    ('Defensive Spec D',        8.907926, 'H1 pooled vol-wtd',       True),
    ('Solo ReAct\n(no split)',    7.683437, 'H2 count-wtd',            False),
]
gold = 8.91

labels = [r[0] for r in runs]
preds  = [r[1] for r in runs]
ints   = [r[2] for r in runs]
passes = [r[3] for r in runs]
colors = ['#1f7a3a' if p else '#a8211f' for p in passes]
edge   = ['black'] * len(runs)

fig, ax = plt.subplots(figsize=(8.0, 3.4))
x = np.arange(len(runs))
bars = ax.bar(x, preds, width=0.7, color=colors, edgecolor=edge, linewidth=0.5)

# Annotate prediction values
for b, v in zip(bars, preds):
    ax.annotate(f'{v:.3f}', xy=(b.get_x() + b.get_width()/2, v),
                xytext=(0, 2), textcoords='offset points',
                ha='center', va='bottom', fontsize=7.5)

# Gold reference line
ax.axhline(gold, linestyle='--', linewidth=1.0, color='#222',
           label=f'gold = {gold} (2dp)')

# Interpretation labels under x-ticks
ax.set_xticks(x)
ax.set_xticklabels(labels, fontsize=8)

# Add interpretation tag below each bar
for i, intl in enumerate(ints):
    ax.text(i, 0.3, intl, ha='center', va='bottom', fontsize=6.5,
            style='italic', color='#444', rotation=0)

ax.set_ylabel('Predicted fraud rate (\\%)', fontsize=10)
ax.set_ylim(0, 10.5)
ax.set_axisbelow(True)
ax.grid(True, axis='y', linestyle=':', alpha=0.4)

# Legend with pass/fail color key
from matplotlib.patches import Patch
legend_elems = [
    Patch(facecolor='#1f7a3a', edgecolor='black', label='passes scorer'),
    Patch(facecolor='#a8211f', edgecolor='black', label='fails scorer'),
    plt.Line2D([0], [0], linestyle='--', color='#222', label=f'gold {gold}'),
]
ax.legend(handles=legend_elems, loc='upper right', fontsize=8, framealpha=0.95)

plt.tight_layout()
plt.savefig('/Users/suraj/Downloads/scribe/paper/figures/task17_crossplanner.pdf',
            bbox_inches='tight', format='pdf')
print('wrote task17_crossplanner.pdf')
