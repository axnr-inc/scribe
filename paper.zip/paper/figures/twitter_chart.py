"""
Twitter chart: SCRIBE cost vs accuracy scatter (Harvey-style).
X = cost per task (decreasing right = cheaper = better)
Y = combined accuracy % on DABStep
"""
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np

matplotlib.rcParams['font.family'] = 'sans-serif'
matplotlib.rcParams['font.sans-serif'] = ['Helvetica Neue', 'Arial', 'DejaVu Sans']
matplotlib.rcParams['pdf.fonttype'] = 42

# ── Data ──────────────────────────────────────────────────────────────────────
# (label, cost_per_task, accuracy_pct, color, size, is_orchestration)
systems = [
    ("Kimi-K2.6\nsolo",          0.04,   46.0,  "#6B6B9B",  180,  False),
    ("GPT-5\nsolo\n(est.)",      1.84,   50.4,  "#222222",  180,  False),
    ("DS-STAR\n(Gemini-2.5)†",   1.50,   52.0,  "#555555",  180,  False),
    ("DS-STAR\n(GPT-5)†",        1.84,   50.4,  "#333333",  160,  False),
    ("SCRIBE\n(ours)",            0.33,   59.8,  "#E8952A",  360,  True),
]

fig, ax = plt.subplots(figsize=(10, 6.5))
ax.set_facecolor('#FAFAFA')
fig.patch.set_facecolor('#FFFFFF')

# Shaded "better" region (top-right)
ax.axvspan(0, 0.6, ymin=0.55, alpha=0.06, color='#E8952A')

# Plot points
for label, cost, acc, color, size, is_orch in systems:
    zorder = 5 if is_orch else 4
    edgecolor = '#C0732A' if is_orch else '#888888'
    lw = 2.0 if is_orch else 0.8
    ax.scatter(cost, acc, s=size, color=color, edgecolors=edgecolor,
               linewidths=lw, zorder=zorder)

# Annotation offsets (cost, acc, dx, dy, ha)
annotations = [
    ("Kimi-K2.6\nsolo",         0.04,  46.0,  0.02,  -3.5, 'left'),
    ("GPT-5 solo\n(est.)",      1.84,  50.4,  -0.03, -4.5, 'right'),
    ("DS-STAR\n(Gemini-2.5)†",  1.50,  52.0,  0.04,   1.0, 'left'),
    ("DS-STAR (GPT-5)†",        1.84,  50.4,   0,     0,   'left'),   # skip — overlaps
    ("SCRIBE (ours)",            0.33,  59.8,  0.03,   1.2, 'left'),
]

for label, cost, acc, dx, dy, ha in annotations:
    if label == "DS-STAR (GPT-5)†":
        continue
    weight = 'bold' if 'SCRIBE' in label else 'normal'
    color  = '#C0732A' if 'SCRIBE' in label else '#222222'
    ax.annotate(label,
                xy=(cost, acc),
                xytext=(cost + dx, acc + dy),
                fontsize=9.5, ha=ha, va='center',
                color=color, fontweight=weight,
                arrowprops=None)

# Cost sub-labels
cost_labels = {
    0.04: "$0.04/task",
    1.84: "$1.84/task",
    1.50: "$1.50/task",
    0.33: "$0.33/task",
}
acc_labels = {
    46.0: "46.0%",
    50.4: "50.4%",
    52.0: "52.0%",
    59.8: "59.8%",
}
for label, cost, acc, is_orch in [(s[0], s[1], s[2], s[5]) for s in systems]:
    if label == "DS-STAR\n(GPT-5)†":
        continue
    sub = f"{acc_labels.get(acc,'')}  ·  {cost_labels.get(cost,'')}"
    color = '#C0732A' if is_orch else '#666666'
    ax.annotate(sub,
                xy=(cost, acc),
                xytext=(cost + (0.03 if cost < 1 else -0.03),
                        acc - 2.0),
                fontsize=8, ha='left' if cost < 1 else 'right',
                color=color, style='italic')

# Arrow: Kimi solo → SCRIBE
ax.annotate("",
            xy=(0.33, 59.8),
            xytext=(0.04, 46.0),
            arrowprops=dict(arrowstyle="-|>", color="#6B4FA0",
                            lw=2.0,
                            connectionstyle="arc3,rad=-0.25"))
ax.text(0.12, 54.5, "+13.8 pts\n−$1.51/task", fontsize=9,
        color="#6B4FA0", fontweight='bold', ha='center')

# Axis formatting
ax.set_xlim(2.2, -0.1)   # reversed: expensive left, cheap right
ax.set_ylim(38, 68)
ax.set_xlabel("Cost per task (USD)   —   cheaper to the right", fontsize=11, labelpad=8)
ax.set_ylabel("DABStep accuracy (%, combined 450 tasks)", fontsize=11, labelpad=8)

ax.xaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(lambda x, _: f"${x:.2f}"))
ax.yaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(lambda y, _: f"{y:.0f}%"))

ax.grid(True, linestyle=':', alpha=0.35, color='#BBBBBB')
ax.set_axisbelow(True)
for spine in ax.spines.values():
    spine.set_visible(False)

ax.set_title("SCRIBE: model orchestration beats frontier-throughout pipelines on DABStep",
             fontsize=13, fontweight='bold', pad=14, loc='left')
ax.text(0, 1.02,
        "DABStep dev set (450 tasks). DS-STAR on hidden test set†. Cost per task estimated from provider pricing.",
        transform=ax.transAxes, fontsize=8.5, color='#666666')

# Legend
orch_patch  = mpatches.Patch(color='#E8952A', label='Orchestrated (spec + executor + review)')
solo_patch  = mpatches.Patch(color='#555555', label='Monolithic frontier / solo open-weights')
ax.legend(handles=[orch_patch, solo_patch], fontsize=9, loc='lower left',
          framealpha=0.9, edgecolor='#CCCCCC')

plt.tight_layout()
out = '/Users/suraj/Downloads/scribe/paper/figures/twitter_chart.png'
plt.savefig(out, dpi=180, bbox_inches='tight', facecolor='white')
print(f"Saved → {out}")
