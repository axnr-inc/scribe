"""Generate krama_per_domain.pdf using matplotlib.
Per-domain comparison: SCRIBE (lenient) vs published smolagents-DR baseline.
One canonical SCRIBE configuration; no re-roll mention.
"""
import matplotlib.pyplot as plt
import numpy as np

domains = ['archeology', 'astronomy', 'biomedical', 'environment', 'legal', 'wildfire', 'Overall']
baseline = [44.4, 50.0, 38.9, 60.6, 61.2, 60.2, 55.8]
scribe   = [50.0, 41.7, 77.8, 80.0, 76.7, 66.7, 68.3]

x = np.arange(len(domains))
width = 0.36

# Larger figure with more headroom so value labels do not collide with
# the legend or the F-E / SCRIBE-wins annotations.
fig, ax = plt.subplots(figsize=(7.6, 4.0))

b1 = ax.bar(x - width/2, baseline, width,
            label='smolagents-DR Claude-3.7 (published baseline)',
            color='#B22222', edgecolor='#7A1313', linewidth=0.5)
b2 = ax.bar(x + width/2, scribe, width,
            label='SCRIBE (lenient, patched scorer)',
            color='#2B5BA0', edgecolor='#1A3A66', linewidth=0.5)

# Value labels just above each bar.
for bars, vals in [(b1, baseline), (b2, scribe)]:
    for bar, v in zip(bars, vals):
        ax.text(bar.get_x() + bar.get_width()/2, v + 1.0, f'{v:.1f}',
                ha='center', va='bottom', fontsize=7)

ax.set_ylabel('Pass rate (%)', fontsize=10)
ax.set_xticks(x)
ax.set_xticklabels(domains, rotation=25, ha='right', fontsize=9)
# Extra headroom (was 100) so annotation boxes do not collide with bar labels.
ax.set_ylim(0, 115)
ax.set_yticks([0, 20, 40, 60, 80, 100])
ax.grid(axis='y', linewidth=0.4, alpha=0.3)
ax.set_axisbelow(True)
# Legend at the bottom outside the plot area so it never overlaps annotations.
ax.legend(loc='upper center', bbox_to_anchor=(0.5, -0.22),
          ncol=2, fontsize=8, frameon=False)

# Vertical separator before Overall
ax.axvline(x=5.5, color='gray', linewidth=0.6, linestyle=':', alpha=0.6)

# Paradigm-fit annotations placed in the headroom band so they do not
# overlap the bar value labels.
ax.text(2.75, 109, 'docs-heavy paradigms: SCRIBE wins',
        ha='center', va='center',
        fontsize=8, color='#2E7D32', weight='bold',
        bbox=dict(boxstyle='round,pad=0.3', facecolor='white',
                  edgecolor='#2E7D32', linewidth=0.5))
ax.text(0.5, 109, 'F-E ceiling',
        ha='center', va='center',
        fontsize=8, color='#B22222', weight='bold',
        bbox=dict(boxstyle='round,pad=0.3', facecolor='white',
                  edgecolor='#B22222', linewidth=0.5))

plt.tight_layout()
plt.savefig('krama_per_domain.pdf', bbox_inches='tight', pad_inches=0.08)
plt.savefig('krama_per_domain.png', bbox_inches='tight', pad_inches=0.08, dpi=200)
print("wrote krama_per_domain.pdf + .png")
