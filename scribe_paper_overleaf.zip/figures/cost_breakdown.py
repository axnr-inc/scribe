"""Per-task cost decomposition by system.

Horizontal stacked bars: one bar per system (Kimi-K2.6 solo, GPT-5 solo,
SCRIBE subset, SCRIBE full-450). Each bar is decomposed into Spec, Executor,
and Review components, with the total annotated at the bar's tip.
"""

import matplotlib
import matplotlib.pyplot as plt
import numpy as np

matplotlib.rcParams["font.family"] = "serif"

# system: (spec, executor, review) in USD per task.
systems = [
    ("Kimi-K2.6 solo",     (0.00, 0.02, 0.00)),
    ("GPT-5 solo (subset)", (0.00, 0.37, 0.00)),
    ("SCRIBE (subset)",     (0.02, 0.06, 0.02)),  # total 0.10
    ("SCRIBE (full-450)",   (0.07, 0.20, 0.06)),  # total 0.33
]

labels = [s[0] for s in systems]
spec  = np.array([s[1][0] for s in systems])
exec_ = np.array([s[1][1] for s in systems])
rev   = np.array([s[1][2] for s in systems])
totals = spec + exec_ + rev

colors = {"Spec": "#4c72b0", "Executor": "#dd8452", "Review": "#55a868"}

fig, ax = plt.subplots(figsize=(12 / 2.54, 7 / 2.54))
y = np.arange(len(labels))
bar_h = 0.55

b1 = ax.barh(y, spec, height=bar_h, color=colors["Spec"],
             edgecolor="black", linewidth=0.4, label="Spec")
b2 = ax.barh(y, exec_, left=spec, height=bar_h, color=colors["Executor"],
             edgecolor="black", linewidth=0.4, label="Executor")
b3 = ax.barh(y, rev, left=spec + exec_, height=bar_h, color=colors["Review"],
             edgecolor="black", linewidth=0.4, label="Review")

# Total label at end of each bar.
for yi, total in zip(y, totals):
    ax.text(total + 0.008, yi, f"\\${total:.2f}",
            va="center", ha="left", fontsize=8.5, fontweight="bold")

ax.set_yticks(y)
ax.set_yticklabels(labels, fontsize=8.5)
ax.invert_yaxis()  # first row at top
ax.set_xlabel("Per-task cost (USD)", fontsize=9)
ax.set_xlim(0, max(totals) * 1.18)
ax.set_title("Per-task cost decomposition by system", fontsize=10)
ax.tick_params(axis="x", labelsize=8)
ax.grid(axis="x", linestyle=":", linewidth=0.5, alpha=0.6)
ax.set_axisbelow(True)

ax.legend(fontsize=8, loc="lower right", frameon=False, ncol=3)

plt.tight_layout()
plt.savefig("paper/figures/cost_breakdown.pdf",
            bbox_inches="tight", format="pdf")
plt.close(fig)
